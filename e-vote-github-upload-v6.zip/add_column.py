from database import SessionLocal, engine
from sqlalchemy import text

db = SessionLocal()

# Add the face_enrolled column if it doesn't exist
db.execute(text("ALTER TABLE users ADD COLUMN face_enrolled BOOLEAN DEFAULT 0"))
db.commit()
db.close()

print("✅ Column added successfully!")


