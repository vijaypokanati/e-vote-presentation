from database import SessionLocal, create_tables
from auth_security import hash_password
import models
import os
import uuid

def seed_database():
    # Create tables first
    create_tables()
    
    db = SessionLocal()
    
    try:
        # Create synthetic example parties and candidates once. These are
        # data-only demo records; no admin or voter passwords are seeded.
        demo_parties = [
            ("Progress Alliance", "✳", "#087cff", "Practical ideas for a stronger community.", "Jordan Lee"),
            ("Community First", "◈", "#18c7a3", "Local voices and shared opportunity.", "Sam Rivera"),
            ("Future Forward", "✦", "#a27cf5", "Responsible innovation for everyone.", "Taylor Morgan"),
        ]
        for name, symbol, color, manifesto, candidate_name in demo_parties:
            party = db.query(models.Party).filter(models.Party.name.ilike(name)).first()
            if not party:
                party = models.Party(id=str(uuid.uuid4()), name=name, symbol=symbol,
                                     color=color, manifesto=manifesto)
                db.add(party)
                db.flush()
            candidate_exists = db.query(models.Candidate).filter(
                models.Candidate.name.ilike(candidate_name),
                models.Candidate.position.ilike("President"),
                models.Candidate.party_id == party.id
            ).first()
            if not candidate_exists:
                db.add(models.Candidate(id=str(uuid.uuid4()), name=candidate_name,
                                        position="President", party_id=party.id))
        
        # Create Election
        if not db.query(models.Election).first():
            election = models.Election(
                id=str(uuid.uuid4()),
                title="Digital Election 2026",
                status="ACTIVE"
            )
            db.add(election)
            print("✅ Election created")

        # Optional presentation accounts are deliberately read-only. Enable
        # them only for the public demo deployment with an explicit env flag.
        if os.getenv("ENABLE_PRESENTATION_ACCOUNTS", "false").lower() == "true":
            presentation_accounts = [
                ("demo_admin", "DemoAdmin2026!", "DEMO_ADMIN"),
                ("demo_voter", "DemoVoter2026!", "DEMO_VOTER"),
            ]
            for username, password, role in presentation_accounts:
                account = db.query(models.User).filter(
                    models.User.username.ilike(username)
                ).first()
                if not account:
                    db.add(models.User(
                        id=str(uuid.uuid4()), username=username,
                        password=hash_password(password), role=role,
                        status="VERIFIED"
                    ))
                    db.flush()

            demo_voter = db.query(models.User).filter_by(username="demo_voter").first()
            election = db.query(models.Election).first()
            if demo_voter and election and not db.query(models.ElectionVoter).filter_by(
                election_id=election.id, user_id=demo_voter.id
            ).first():
                db.add(models.ElectionVoter(
                    id=str(uuid.uuid4()), election_id=election.id,
                    user_id=demo_voter.id
                ))


        
        db.commit()
        print("\n🎉 Database seeded successfully!")
        
    except Exception as e:
        db.rollback()
        print(f"❌ Error seeding database: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()

